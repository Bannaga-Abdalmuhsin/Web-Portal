import { defineConfig, Plugin } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';
import { createServer } from './server';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  // Determine base path based on environment
  // Use '/' for most deployments (fly.dev, Vercel, Netlify, etc.)
  // Use './' only if VITE_BASE_PATH env var is explicitly set
  base: process.env.VITE_BASE_PATH || '/',
  server: {
    host: '::',
    port: 8080,
    fs: {
      allow: [
        path.resolve(__dirname, '.'),
        path.resolve(__dirname, './client'),
        path.resolve(__dirname, './shared'),
      ],
      deny: ['.env', '.env.*', '*.{crt,pem}', '**/.git/**', 'server/**'],
    },
  },
  build: {
    outDir: 'dist/spa',
  },
  plugins: [react(), expressPlugin()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './client'),
      '@shared': path.resolve(__dirname, './shared'),
    },
  },
}));

function expressPlugin(): Plugin {
  return {
    name: 'express-plugin',
    apply: 'serve', // Only apply during development (serve mode)
    configureServer(server) {
      const app = createServer();

      // Add Express app as middleware to Vite dev server
      server.middlewares.use(app);
    },
  };
}
